from easy_plotly.linegraph import LineGraph
from easy_plotly.bubblegraph import BubbleGraph
from easy_plotly.bargraph import BarGraph
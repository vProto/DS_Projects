from setuptools import setup

setup(name='easy_plotly',
      version='0.2',
      description='Making Plotly charting easy',
      packages=['easy_plotly'],
      zip_safe=False)